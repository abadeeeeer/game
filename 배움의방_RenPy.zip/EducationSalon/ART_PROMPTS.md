# 최종 이미지 제작 기록

사용자의 최신 게임 화면을 스타일·화면 구성 참고로 삼아 내장 이미지 생성 도구(image_gen)로 새로 제작했습니다. 픽셀 아트의 선·팔레트·디더링을 참고했으며 기존 게임의 캐릭터나 로고는 사용하지 않았습니다. 인물은 실제 초상 복제가 아닌 창작 해석입니다. 기존 아날로그 삽화는 최종 게임에 사용하지 않습니다.

각 인물 시트는 왼쪽부터 평상시·칭찬·꾸중 세 표정이며 투명 배경입니다. 원본을 별도 이미지 편집 없이 그대로 동봉하고 게임 실행 중 해당 칸을 표시합니다.

## toegye

파일: game/images/toegye_pixel.png

도구: OpenAI built-in image_gen; transparent_background=true

### 사용 프롬프트

```text
Use case: illustration-story. Asset: a NEW ORIGINAL transparent character expression sprite sheet for an educational retro visual novel. The input images are STYLE/PIXEL MEDIUM references ONLY, never edit targets, and their existing fictional characters must not be copied. Match the visual language: late-1980s Japanese PC adventure game pixel art, bold dark navy pixel outlines, cel-shaded anime-inspired faces with realistic adult proportions, clearly visible coarse square pixel clusters, restrained olive-gray/navy/cream palette, hard pixel edges and selective ordered dithering. Not a painting or modern smooth illustration, no paper texture, no pencil lines, no soft antialiasing or glossy rendering. Draw at a convincing low native pixel resolution and present cleanly upscaled with a consistent pixel grid. Layout: landscape canvas1536x1024, EXACTLY THREE equal512pixel-wide vertical columns. One waist-up portrait of the SAME single character centered in EACH column, same size, body pose, clothing, light and placement. Left expression neutral attentive; middle happy approving smile; right angry stern knitted brows. Keep expressions unmistakable but dignified. All heads, hats and hair fully inside columns, shoulder+robe/suit reaches bottom edge. Transparent background around character silhouette in all three columns with real clean alpha; no frames, no shadows, no background, no text, no labels, no symbols, no decorative UI, no logos, no extra people. Subject: Toegye Yi Hwang, elderly Korean Joseon philosopher, long silver-white beard, narrow wise face, modest black yugeon Confucian cap, ivory cream traditional scholar hanbok. Historical recognizable clothing, translated into mature retro anime pixel-art design.
```

## yulgok

파일: game/images/yulgok_pixel.png

도구: OpenAI built-in image_gen; transparent_background=true

### 사용 프롬프트

```text
Use case: illustration-story. Asset: a NEW ORIGINAL transparent character expression sprite sheet for an educational retro visual novel. The input images are STYLE/PIXEL MEDIUM references ONLY, never edit targets, and their existing fictional characters must not be copied. Match the visual language: late-1980s Japanese PC adventure game pixel art, bold dark navy pixel outlines, cel-shaded anime-inspired faces with realistic adult proportions, clearly visible coarse square pixel clusters, restrained olive-gray/navy/cream palette, hard pixel edges and selective ordered dithering. Not a painting or modern smooth illustration, no paper texture, no pencil lines, no soft antialiasing or glossy rendering. Draw at a convincing low native pixel resolution and present cleanly upscaled with a consistent pixel grid. Layout: landscape canvas1536x1024, EXACTLY THREE equal512pixel-wide vertical columns. One waist-up portrait of the SAME single character centered in EACH column, same size, body pose, clothing, light and placement. Left expression neutral attentive; middle happy approving smile; right angry stern knitted brows. Keep expressions unmistakable but dignified. All heads, hats and hair fully inside columns, shoulder+robe/suit reaches bottom edge. Transparent background around character silhouette in all three columns with real clean alpha; no frames, no shadows, no background, no text, no labels, no symbols, no decorative UI, no logos, no extra people. Subject: Yulgok Yi I, middle-aged Korean Joseon philosopher, black medium-length beard and moustache, broad reflective face, modest black yugeon cap, desaturated sage-green traditional scholar hanbok. Historical recognizable clothing translated into mature retro anime pixel-art design, clearly distinct from elderly white-bearded Yi Hwang.
```

## dewey

파일: game/images/dewey_pixel.png

도구: OpenAI built-in image_gen; transparent_background=true

### 사용 프롬프트

```text
Use case: illustration-story. Asset: a NEW ORIGINAL transparent character expression sprite sheet for an educational retro visual novel. The input images are STYLE/PIXEL MEDIUM references ONLY, never edit targets, and their existing fictional characters must not be copied. Match the visual language: late-1980s Japanese PC adventure game pixel art, bold dark navy pixel outlines, cel-shaded anime-inspired faces with realistic adult proportions, clearly visible coarse square pixel clusters, restrained olive-gray/navy/cream palette, hard pixel edges and selective ordered dithering. Not a painting or modern smooth illustration, no paper texture, no pencil lines, no soft antialiasing or glossy rendering. Draw at a convincing low native pixel resolution and present cleanly upscaled with a consistent pixel grid. Layout: landscape canvas1536x1024, EXACTLY THREE equal512pixel-wide vertical columns. One waist-up portrait of the SAME single character centered in EACH column, same size, body pose, clothing, light and placement. Left expression neutral attentive; middle happy approving smile; right angry stern knitted brows. Keep expressions unmistakable but dignified. All heads, hats and hair fully inside columns, shoulder+robe/suit reaches bottom edge. Transparent background around character silhouette in all three columns with real clean alpha; no frames, no shadows, no background, no text, no labels, no symbols, no decorative UI, no logos, no extra people. Subject: John Dewey, elderly white American educator, long elderly face, thinning white hair high receding hairline, small white moustache, NO beard, a muted brown tweed suit cream shirt dark tie. His mature face should be an appealing recognizable retro anime pixel-art interpretation, no eyewear.
```

## peters

파일: game/images/peters_pixel.png

도구: OpenAI built-in image_gen; transparent_background=true

### 사용 프롬프트

```text
Use case: illustration-story. Asset: a NEW ORIGINAL transparent character expression sprite sheet for an educational retro visual novel. The input images are STYLE/PIXEL MEDIUM references ONLY, never edit targets, and their existing fictional characters must not be copied. Match the visual language: late-1980s Japanese PC adventure game pixel art, bold dark navy pixel outlines, cel-shaded anime-inspired faces with realistic adult proportions, clearly visible coarse square pixel clusters, restrained olive-gray/navy/cream palette, hard pixel edges and selective ordered dithering. Not a painting or modern smooth illustration, no paper texture, no pencil lines, no soft antialiasing or glossy rendering. Draw at a convincing low native pixel resolution and present cleanly upscaled with a consistent pixel grid. Layout: landscape canvas1536x1024, EXACTLY THREE equal512pixel-wide vertical columns. One waist-up portrait of the SAME single character centered in EACH column, same size, body pose, clothing, light and placement. Left expression neutral attentive; middle happy approving smile; right angry stern knitted brows. Keep expressions unmistakable but dignified. All heads, hats and hair fully inside columns, shoulder+robe/suit reaches bottom edge. Transparent background around character silhouette in all three columns with real clean alpha; no frames, no shadows, no background, no text, no labels, no symbols, no decorative UI, no logos, no extra people. Subject: Richard S. Peters, late middle-aged white British education philosopher, short neatly side-parted gray hair, clean-shaven face, narrow intellectual features, muted slate blue-gray suit cream shirt dark tie. Mature retro anime pixel-art design, clearly distinct from white-haired moustached John Dewey.
```

## pixel_background

파일: game/images/pixel_background.png

도구: OpenAI built-in image_gen; transparent_background=false

### 사용 프롬프트

```text
Use case: illustration-story. Asset: NEW ORIGINAL landscape background for an educational retro pixel-art visual novel. Input images are STYLE/MEDIUM references only, do not copy their characters, logos or story. A quiet empty classroom redesigned as a late-1980s PC anime adventure setting: broad dark chalkboard centered at the back, olive-gray metal wall panels and a few simple side cabinets, one window on left with pale cyan light, simple overhead fixtures and gray-blue floor perspective. Restrained industrial-school atmosphere, not outer space and no vehicles. The central foreground is completely open so four waist-up philosopher sprites can stand side by side. True retro pixel art: coarse visible square pixels, hard navy outlines, flat cel-shaded clusters, limited olive-gray/dark-navy/cream/cyan colors, selective ordered dithering, clean low-resolution native aesthetic presented as a crisp 16:9 landscape 1600x900. No smooth painting, gradients, photo texture, pencil hatching or antialiasing. No people, no figures, no UI panels, no typography, no letters, no writing, no logos, no symbols, no captions, no watermarks, no border. Muted mid-dark lighting with clear silhouettes and strong scene depth.
```

