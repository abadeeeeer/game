# 1600 × 900: pixel scene, olive machine frame, right rail, navy dialogue.
define SALON_PAPER = "#e2e8d5"
define SALON_RED = "#e4a08b"

init python:
    def salon_ui_font():
        for path in ("fonts/DungGeunMo.ttf", "fonts/DungGeunMo.otf", "fonts/Galmuri11.ttf"):
            if renpy.loadable(path):
                return path
        return "fonts/Pretendard-Regular.otf"

style default:
    font "fonts/Pretendard-Regular.otf"
    size 24
    color "#e2e8d5"
    language "korean-with-spaces"

style salon_button:
    background Solid("#707963")
    hover_background Solid("#a1ad8c")
    insensitive_background Solid("#454e46")
    padding (20, 15)
    yminimum 60

style salon_button_text:
    font "fonts/Pretendard-Regular.otf"
    size 23
    color "#edf1df"
    hover_color "#ffffff"
    insensitive_color "#8e9986"
    yalign 0.5

style salon_dark_button is salon_button:
    background Solid("#263e45")
    hover_background Solid("#3e5961")

style salon_dark_button_text is salon_button_text:
    size 21

transform salon_tone(muted=False):
    blur (5.0 if muted else 0.0)
    matrixcolor BrightnessMatrix(-0.53 if muted else 0.0)
    alpha (0.82 if muted else 1.0)
    nearest True

screen salon_frame(x, y, width, height, inner="#071b24", outer="#707963"):
    add Solid("#172c32") xpos x ypos y xsize width ysize height
    add Solid(outer) xpos x ypos y xsize (width-5) ysize (height-5)
    add Solid("#a0a88d") xpos x ypos y xsize (width-5) ysize 3
    add Solid("#a0a88d") xpos x ypos y xsize 3 ysize (height-5)
    add Solid("#414c3f") xpos (x+width-8) ypos (y+3) xsize 5 ysize (height-8)
    add Solid("#414c3f") xpos (x+3) ypos (y+height-8) xsize (width-8) ysize 5
    add Solid(inner) xpos (x+8) ypos (y+8) xsize (width-16) ysize (height-16)

screen salon_machine(s=None, title=False):
    add Solid("#505a4d")
    use salon_frame(16, 16, 1568, 868, inner="#707963")
    use salon_frame(40, 40, 1140, 548)
    add salon_background() xpos 48 ypos 48
    if s or title:
        $ focus, expression = salon_focus(s) if s else (None, "neutral")
        for i, c in enumerate(SALON_CHARACTERS):
            $ active = focus == c["id"]
            $ muted = bool(focus and not active)
            add salon_sprite(c["id"], expression if active else "neutral") xpos (48+i*281) ypos 48 at salon_tone(muted)
        if s and s["phase"] == "choose_thinker":
            for i, c in enumerate(SALON_CHARACTERS):
                button:
                    xpos (48+i*281)
                    ypos 48
                    xysize (281, 532)
                    padding (0, 0)
                    background None
                    hover_foreground Solid("#d5e6b51a")
                    action Return(("thinker", c["id"]))
    use salon_frame(40, 614, 1140, 246)
    use salon_frame(1204, 40, 356, 820, inner="#152c34")

screen salon_rail_button(index, label, action_value, y, height=158):
    button:
        xpos 1222
        ypos y
        xysize (320, height)
        padding (3, 3)
        background Solid("#899477")
        hover_background Solid("#c2cba8")
        hover_foreground Solid("#e4f4ca14")
        action action_value
        fixed:
            xysize (314, height-6)
            add Solid("#203a43")
            add Solid("#53634d") xsize 314 ysize 4
            add Solid("#0b222c") ypos (height-10) xsize 314 ysize 4
            vbox:
                xpos 17
                yalign 0.5
                xsize 280
                spacing 6
                if index:
                    text ("%02d" % index) font salon_ui_font() size 15 color "#a9bb91"
                text label font salon_ui_font() size 21 color "#edf1df" line_spacing 8

screen salon_menu_button():
    use salon_rail_button(0, "메뉴", ShowMenu("salon_pause"), 788, 54)

screen salon_dialogue(speaker, body, next_label=None, next_event=("next",), secondary=""):
    text speaker font salon_ui_font() xpos 65 ypos 637 size 26 color "#c4d7a5"
    add Solid("#6e856b") xpos 64 ypos 677 xsize 1092 ysize 2
    if body:
        if next_label:
            button:
                xpos 64
                ypos 699
                xysize (1090, 110)
                padding (0, 0)
                background None
                action Return(next_event)
                text body font salon_ui_font() size 26 color "#e8eddc" line_spacing 12
        else:
            text body font salon_ui_font() xpos 64 ypos 699 xsize 1090 size 26 color "#e8eddc" line_spacing 12
    if secondary:
        text secondary font salon_ui_font() xpos 65 ypos 788 xsize 870 size 20 color "#abbf9b" line_spacing 7
    if next_label:
        textbutton (next_label+"  ≫"):
            style "salon_dark_button"
            text_font salon_ui_font()
            text_size 23
            xpos 1154
            xanchor 1.0
            ypos 805
            ysize 47
            action Return(next_event)

screen salon_narrative(s):
    $ phase = s["phase"]
    if phase == "intro":
        $ speaker = "안내"
        $ body = SALON_DATA["intro"][s["intro_index"]]
        $ label = "대화 시작" if s["intro_index"] == len(SALON_DATA["intro"])-1 else "계속"
    elif phase == "outro":
        $ speaker = "안내"
        $ body = SALON_DATA["outro"][s["outro_index"]]
        $ label = "결과 보기" if s["outro_index"] == len(SALON_DATA["outro"])-1 else "계속"
    else:
        $ c = salon_character(s["thinker"])
        $ topic = c["topics"][s["topic_index"]]
        $ speaker = c["full_name"]
        $ body = topic["lines"][s["line_index"]]
        $ label = "이해했어요" if s["line_index"] == len(topic["lines"])-1 else "계속"
    use salon_dialogue(speaker, body, label)
    use salon_rail_button(0, "계속  ≫", Return(("next",)), 60, 105)

screen salon_choose_thinker(s):
    for i, c in enumerate(SALON_CHARACTERS):
        $ completed = len(s["learned"][c["id"]]) == 3
        use salon_rail_button(i+1, c["full_name"]+("  ✓" if completed else ""), Return(("thinker", c["id"])), 60+i*166)
    use salon_dialogue("안내", "누구의 생각부터 들어 볼까요? 궁금한 사상가를 선택하세요. 네 사람의 세 가지 관점을 모두 들으면 퀴즈가 열립니다.")

screen salon_choose_topic(s):
    $ c = salon_character(s["thinker"])
    for i, topic in enumerate(c["topics"]):
        $ done = i in s["learned"][c["id"]]
        use salon_rail_button(i+1, ("✓ " if done else "")+topic["title"], Return(("topic", i)), 60+i*166)
    use salon_rail_button(4, "다른 사상가 만나기", Return(("back",)), 558)
    use salon_dialogue(c["full_name"], "어떤 이야기를 나누겠는가? 궁금한 질문을 고르게. 배운 주제도 다시 이야기할 수 있네.")

screen salon_lesson_complete(s):
    use salon_dialogue("안내", "이제 여덟 가지 상황을 만나게 됩니다. 빛이 켜진 사상가가 어떤 답을 할지 네 개의 선택지에서 골라 보세요. 선택 뒤에는 정답과 이유를 함께 살펴봅니다.", "퀴즈 시작", ("start_quiz",))
    use salon_rail_button(0, "상황 퀴즈 시작  ≫", Return(("start_quiz",)), 60, 105)

screen salon_attribution_intro(s):
    use salon_dialogue("안내", "마지막 네 개의 질문입니다. 문장에 담긴 생각을 읽고 네 사상가 중 한 사람을 선택하세요. 답을 고르기 전까지 네 사람은 같은 모습으로 기다립니다.", "시작")
    use salon_rail_button(0, "입장 퀴즈 시작  ≫", Return(("next",)), 60, 105)

screen salon_quiz(s):
    $ q = salon_question(s)
    $ attribution = s["question_index"] >= len(SALON_DATA["situations"])
    $ speaker = "누구의 생각일까요?" if attribution else salon_character(q["thinker"])["full_name"]
    for i, option in enumerate(q["options"]):
        use salon_rail_button(i+1, option, Return(("answer", i)), 60+i*166)
    use salon_dialogue(speaker, q["prompt"])

screen salon_feedback(s):
    $ q = salon_question(s)
    $ r = s["results"][-1]
    $ c = salon_character(q["thinker"])
    $ correct = r["correct"]
    $ title = c["praise"] if correct else c["scold"]
    # Keep all four heads visible above a readable explanation panel in the scene.
    use salon_frame(62, 328, 1096, 240, inner="#0a222cf5")
    vbox:
        xpos 80
        ypos 346
        xsize 1060
        spacing 12
        text ("정답 %02d  %s" % (q["answer"]+1, q["options"][q["answer"]])) font salon_ui_font() size 21 color "#c5d5aa" line_spacing 6
        if not correct:
            text ("{color=#e4a08b}내 선택 %02d{/color}  %s" % (r["answer"]+1, q["explanations"][r["answer"]])) font salon_ui_font() size 20 color "#e0d9c7" line_spacing 7
        text ("{color=#a6c7bb}정답 해설{/color}  "+q["explanations"][q["answer"]]) font salon_ui_font() size 20 color "#e0e7d5" line_spacing 7
    use salon_dialogue(c["full_name"], title, "마무리" if s["question_index"] == len(SALON_QUESTIONS)-1 else "다음", secondary=q["takeaway"])
    use salon_rail_button(0, "다음  ≫", Return(("next",)), 60, 105)

screen salon_modal(title):
    add Solid("#06171ee8")
    use salon_frame(156, 95, 1288, 710, inner="#102a34")
    text title font salon_ui_font() xpos 190 ypos 126 size 34 color "#c6d5ae"
    add Solid("#6e856b") xpos 188 ypos 183 xsize 1217 ysize 2

screen salon_review(s):
    $ q = salon_question(s)
    $ r = salon_wrong(s)[s["review_index"]]
    $ c = salon_character(q["thinker"])
    use salon_modal("틀린 문제 복습")
    vbox:
        xpos 190
        ypos 213
        xsize 1215
        spacing 22
        text c["full_name"] font salon_ui_font() size 25 color "#c5d5aa"
        text q["prompt"] font salon_ui_font() size 25 color "#e8eddc" line_spacing 9
        text ("정답 %02d  %s" % (q["answer"]+1, q["options"][q["answer"]])) font salon_ui_font() size 23 color "#c5d5aa" line_spacing 8
        text ("{color=#e4a08b}내 선택 %02d{/color}  %s" % (r["answer"]+1, q["explanations"][r["answer"]])) font salon_ui_font() size 22 color "#e0d9c7" line_spacing 8
        text ("{color=#a6c7bb}정답 해설{/color}  "+q["explanations"][q["answer"]]) font salon_ui_font() size 22 color "#e0e7d5" line_spacing 8
        text q["takeaway"] font salon_ui_font() size 20 color "#aabc9d" line_spacing 7
    hbox:
        xpos 1408
        xanchor 1.0
        ypos 709
        spacing 17
        textbutton "결과로":
            style "salon_dark_button"
            text_font salon_ui_font()
            action Return(("back",))
        textbutton ("복습 마치기  ≫" if s["review_index"] == len(salon_wrong(s))-1 else "다음 문제  ≫"):
            style "salon_button"
            text_font salon_ui_font()
            action Return(("next",))

screen salon_results(s):
    $ score = salon_score(s)
    $ wrong = salon_wrong(s)
    use salon_modal("대화 결과")
    text ("%d / 12" % score) font salon_ui_font() xpos 1405 xanchor 1.0 ypos 124 size 42 color "#d8e5be"
    grid 2 2:
        xpos 190
        ypos 236
        spacing 32
        for c in SALON_CHARACTERS:
            vbox:
                xysize (592, 178)
                spacing 18
                text c["full_name"] font salon_ui_font() size 26 color "#c5d5aa"
                text c["summary"] font salon_ui_font() size 23 color "#e0e7d5" xsize 579 line_spacing 8
    hbox:
        xpos 1408
        xanchor 1.0
        ypos 709
        spacing 17
        if wrong:
            textbutton ("틀린 %d문제 복습" % len(wrong)):
                style "salon_button"
                text_font salon_ui_font()
                action Return(("review",))
        textbutton "처음부터":
            style "salon_dark_button"
            text_font salon_ui_font()
            action Return(("restart",))

screen salon_play(s):
    tag salon
    use salon_machine(s)
    if s["phase"] in ("intro", "topic", "outro"):
        use salon_narrative(s)
    elif s["phase"] == "choose_thinker":
        use salon_choose_thinker(s)
    elif s["phase"] == "choose_topic":
        use salon_choose_topic(s)
    elif s["phase"] == "lesson_complete":
        use salon_lesson_complete(s)
    elif s["phase"] == "attribution_intro":
        use salon_attribution_intro(s)
    elif s["phase"] == "quiz":
        use salon_quiz(s)
    elif s["phase"] == "feedback":
        use salon_feedback(s)
    elif s["phase"] == "review":
        use salon_review(s)
    elif s["phase"] == "results":
        use salon_results(s)
    if s["phase"] not in ("results", "review"):
        use salon_menu_button
    key "game_menu" action ShowMenu("salon_pause")
    key "K_F5" action QuickSave()
    key "K_F9" action QuickLoad(confirm=True)
    if s["phase"] in ("intro", "topic", "feedback", "attribution_intro", "outro", "review"):
        key "K_RETURN" action Return(("next",))
        key "K_KP_ENTER" action Return(("next",))
        key "K_SPACE" action Return(("next",))
    elif s["phase"] == "lesson_complete":
        key "K_RETURN" action Return(("start_quiz",))
        key "K_SPACE" action Return(("start_quiz",))
    if s["phase"] == "quiz":
        for i in range(4):
            key ("K_%d" % (i+1)) action Return(("answer", i))
            key ("K_KP%d" % (i+1)) action Return(("answer", i))
    elif s["phase"] == "choose_thinker":
        for i, c in enumerate(SALON_CHARACTERS):
            key ("K_%d" % (i+1)) action Return(("thinker", c["id"]))
    elif s["phase"] == "choose_topic":
        for i in range(3):
            key ("K_%d" % (i+1)) action Return(("topic", i))
        key "K_4" action Return(("back",))

screen main_menu():
    tag menu
    use salon_machine(title=True)
    add Solid("#06171e99") xpos 48 ypos 48 xsize 1124 ysize 532
    text "배움의 방" font salon_ui_font() xpos 610 xanchor 0.5 ypos 237 size 80 color "#dfebc7" outlines [(4, "#09212a", 4, 4)]
    use salon_rail_button(1, "시작", Start(), 60)
    use salon_rail_button(2, "불러오기", ShowMenu("load"), 226)
    use salon_rail_button(3, "이용 안내", ShowMenu("salon_help"), 392)
    use salon_rail_button(4, "종료", Quit(confirm=False), 558)
    use salon_dialogue("안내", "네 사상가와 대화하며 교육의 의미를 알아보세요. 대화를 마치면 상황 퀴즈와 사상가 찾기에 도전합니다.")

screen salon_pause():
    tag menu
    use salon_machine(salon)
    use salon_modal("메뉴")
    grid 2 4:
        xpos 190
        ypos 225
        spacing 22
        textbutton "재개  ≫":
            style "salon_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action Return()
        textbutton "저장":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action ShowMenu("save")
        textbutton "불러오기":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action ShowMenu("load")
        textbutton "대화 기록":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action ShowMenu("salon_record")
        textbutton "전체 화면":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action Preference("display", "toggle")
        textbutton "이용 안내":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action ShowMenu("salon_help")
        textbutton "첫 화면":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action MainMenu(confirm=False)
        textbutton "종료":
            style "salon_dark_button"
            text_font salon_ui_font()
            xysize (592, 96)
            action Quit(confirm=False)
    text "F5 빠른 저장  ·  F9 빠른 불러오기  ·  ESC 재개" font salon_ui_font() xpos 190 ypos 740 size 20 color "#aabc9d"
    key "game_menu" action Return()

screen salon_file_slots(mode):
    use salon_machine
    use salon_modal("저장" if mode == "save" else "불러오기")
    hbox:
        xpos 190
        ypos 230
        spacing 23
        for i in range(3):
            $ slot = "salon-%d" % (i+1)
            button:
                xysize (389, 340)
                background Solid("#203a43")
                hover_background Solid("#3e5961")
                padding (15, 18)
                action (FileSave(slot) if mode == "save" else FileLoad(slot))
                vbox:
                    spacing 18
                    text ("기록 %02d" % (i+1)) font salon_ui_font() size 26 color "#c5d5aa"
                    add FileScreenshot(slot) xysize (359, 202)
                    text FileTime(slot, format="%Y.%m.%d  %H:%M", empty="비어 있음") font salon_ui_font() size 20 color "#b9c9a8"
    hbox:
        xpos 190
        ypos 694
        spacing 17
        textbutton "돌아가기":
            style "salon_dark_button"
            text_font salon_ui_font()
            action Return()
        textbutton ("빠른 저장" if mode == "save" else "빠른 저장 불러오기"):
            style "salon_button"
            text_font salon_ui_font()
            action (QuickSave() if mode == "save" else QuickLoad(confirm=True))
    key "game_menu" action Return()

screen save():
    tag menu
    use salon_file_slots("save")

screen load():
    tag menu
    use salon_file_slots("load")

screen salon_help():
    tag menu
    use salon_machine
    use salon_modal("이용 안내")
    viewport:
        xpos 190
        ypos 221
        xysize (1210, 425)
        mousewheel True
        draggable True
        vbox:
            xsize 1175
            spacing 26
            text "대화" font salon_ui_font() size 27 color "#c5d5aa"
            text "네 사상가에게 세 가지 주제를 물어봅니다. 12개 주제를 모두 들으면 퀴즈가 열립니다. 완료한 주제에는 ✓ 표시가 붙습니다." font salon_ui_font() size 23 line_spacing 9
            text "퀴즈" font salon_ui_font() size 27 color "#c5d5aa"
            text "상황 퀴즈 8문제와 사상가 찾기 4문제, 총 12문제입니다. 매번 정답과 이유를 확인하고 결과에서 오답을 복습할 수 있습니다." font salon_ui_font() size 23 line_spacing 9
            text "조작" font salon_ui_font() size 27 color "#c5d5aa"
            text "마우스로 선택 · ENTER / SPACE 대사 진행 · 1 ~ 4 선택 · ESC 메뉴\nF5 빠른 저장 · F9 빠른 불러오기\n메뉴에서 저장 · 불러오기 · 대화 기록 · 전체 화면을 이용할 수 있습니다." font salon_ui_font() size 23 line_spacing 10
            text "학습 안내" font salon_ui_font() size 27 color "#c5d5aa"
            text "모든 대사는 사용자가 제공한 학습 제시문을 재구성한 창작입니다. 실제 발언이나 직접 인용이 아닙니다. 네 사람의 견해는 서로 완전히 배타적이지 않습니다. 특히 이황과 이이는 모두 일상에서의 실천을 중시합니다. 퀴즈에서는 제시문에 나타난 각자의 강조점을 구분합니다." font salon_ui_font() size 23 line_spacing 10
    textbutton "돌아가기":
        style "salon_dark_button"
        text_font salon_ui_font()
        xpos 190
        ypos 694
        action Return()
    key "game_menu" action Return()

screen salon_record():
    tag menu
    use salon_machine
    use salon_modal("대화 기록")
    viewport:
        xpos 190
        ypos 221
        xysize (1210, 425)
        mousewheel True
        draggable True
        vbox:
            xsize 1175
            spacing 28
            for line in salon.get("history", []):
                vbox:
                    spacing 13
                    text line["speaker"] font salon_ui_font() size 24 color "#c5d5aa"
                    text line["text"] font salon_ui_font() size 23 line_spacing 10
    textbutton "돌아가기":
        style "salon_dark_button"
        text_font salon_ui_font()
        xpos 190
        ypos 694
        action Return()
    key "game_menu" action Return()

screen confirm(message, yes_action, no_action):
    modal True
    zorder 200
    add Solid("#06171eeb")
    use salon_frame(330, 280, 940, 340, inner="#102a34")
    vbox:
        xpos 370
        ypos 324
        xsize 860
        spacing 35
        text message font salon_ui_font() size 27 color SALON_PAPER line_spacing 10
        hbox:
            spacing 20
            textbutton "예":
                style "salon_button"
                text_font salon_ui_font()
                action yes_action
            textbutton "아니요":
                style "salon_dark_button"
                text_font salon_ui_font()
                action no_action
    key "game_menu" action no_action

screen notify(message):
    zorder 100
    frame:
        xalign 0.5
        ypos 30
        background Solid("#102a34f5")
        padding (24, 13)
        text message font salon_ui_font() size 22 color SALON_PAPER
    timer 2.5 action Hide("notify")
