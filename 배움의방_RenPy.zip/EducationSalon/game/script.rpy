# 모든 대사는 제공된 교육 제시문을 바탕으로 재구성한 창작 대사입니다.
# 텍스트는 content.json에서 바꾸고, 장면 및 선택지는 이 상태 전이로 처리합니다.
init python:
    import json
    import copy

    with renpy.file("content.json") as salon_content_file:
        SALON_DATA = json.loads(salon_content_file.read().decode("utf-8"))
    del salon_content_file
    SALON_CHARACTERS = SALON_DATA["characters"]
    SALON_QUESTIONS = SALON_DATA["situations"] + SALON_DATA["attribution"]
    SALON_TOPICS = sum(len(c["topics"]) for c in SALON_CHARACTERS)

    def salon_new_state():
        return dict(version=1, phase="intro", intro_index=0,
                    learned={c["id"]: [] for c in SALON_CHARACTERS},
                    thinker=None, topic_index=0, line_index=0,
                    question_index=0, selected=None, results=[],
                    review_index=0, outro_index=0,
                    history=[dict(speaker="안내", text=SALON_DATA["intro"][0])])

    def salon_character(identifier):
        return next(c for c in SALON_CHARACTERS if c["id"] == identifier)

    def salon_learned(s):
        return sum(len(v) for v in s["learned"].values())

    def salon_score(s):
        return sum(1 for r in s["results"] if r["correct"])

    def salon_wrong(s):
        return [r for r in s["results"] if not r["correct"]]

    def salon_question(s):
        if s["phase"] == "review":
            return SALON_QUESTIONS[salon_wrong(s)[s["review_index"]]["question_index"]]
        return SALON_QUESTIONS[min(s["question_index"], len(SALON_QUESTIONS)-1)]

    def salon_focus(s):
        phase = s["phase"]
        if phase in ("choose_topic", "topic"):
            return (s["thinker"], "neutral")
        if phase == "quiz" and s["question_index"] < len(SALON_DATA["situations"]):
            return (salon_question(s)["thinker"], "neutral")
        if phase == "feedback":
            q = salon_question(s)
            return (q["thinker"], "happy" if s["selected"] == q["answer"] else "angry")
        if phase == "review":
            return (salon_question(s)["thinker"], "neutral")
        return (None, "neutral")

    def salon_reduce(previous, event):
        """Return a new state; reject out-of-phase events and duplicate answers."""
        s = copy.deepcopy(previous)
        if not event:
            return s
        kind = event[0]
        phase = s["phase"]
        if kind == "restart":
            return salon_new_state()
        if kind == "thinker" and phase == "choose_thinker" and event[1] in s["learned"]:
            s["thinker"] = event[1]
            s["phase"] = "choose_topic"
        elif kind == "topic" and phase == "choose_topic" and 0 <= event[1] < 3:
            s["topic_index"] = event[1]
            s["line_index"] = 0
            s["phase"] = "topic"
        elif kind == "back":
            if phase == "choose_topic":
                s["phase"] = "choose_thinker"
            elif phase == "review":
                s["phase"] = "results"
        elif kind == "start_quiz" and phase == "lesson_complete" and salon_learned(s) == SALON_TOPICS:
            s["phase"] = "quiz"
        elif kind == "answer" and phase == "quiz" and s["selected"] is None:
            q = salon_question(s)
            if 0 <= event[1] < 4 and not any(r["question_index"] == s["question_index"] for r in s["results"]):
                s["selected"] = event[1]
                s["results"].append(dict(question_index=s["question_index"], answer=event[1], correct=event[1] == q["answer"]))
                s["phase"] = "feedback"
        elif kind == "review" and phase == "results" and salon_wrong(s):
            s["review_index"] = 0
            s["phase"] = "review"
        elif kind == "next":
            if phase == "intro":
                s["intro_index"] += 1
                if s["intro_index"] >= len(SALON_DATA["intro"]):
                    s["phase"] = "choose_thinker"
            elif phase == "topic":
                c = salon_character(s["thinker"])
                s["line_index"] += 1
                if s["line_index"] >= len(c["topics"][s["topic_index"]]["lines"]):
                    if s["topic_index"] not in s["learned"][c["id"]]:
                        s["learned"][c["id"]].append(s["topic_index"])
                    s["line_index"] = 0
                    if salon_learned(s) == SALON_TOPICS:
                        s["phase"] = "lesson_complete"
                    elif len(s["learned"][c["id"]]) == len(c["topics"]):
                        s["phase"] = "choose_thinker"
                    else:
                        s["phase"] = "choose_topic"
            elif phase == "feedback":
                s["question_index"] += 1
                s["selected"] = None
                if s["question_index"] >= len(SALON_QUESTIONS):
                    s["phase"] = "outro"
                    s["outro_index"] = 0
                elif s["question_index"] == len(SALON_DATA["situations"]):
                    s["phase"] = "attribution_intro"
                else:
                    s["phase"] = "quiz"
            elif phase == "attribution_intro":
                s["phase"] = "quiz"
            elif phase == "outro":
                s["outro_index"] += 1
                if s["outro_index"] >= len(SALON_DATA["outro"]):
                    s["phase"] = "results"
            elif phase == "review":
                s["review_index"] += 1
                if s["review_index"] >= len(salon_wrong(s)):
                    s["phase"] = "results"
        entry = salon_record_line(s)
        if entry and entry != salon_record_line(previous):
            s["history"].append(entry)
        return s

    def salon_record_line(s):
        phase = s["phase"]
        if phase == "intro":
            return dict(speaker="안내", text=SALON_DATA["intro"][s["intro_index"]])
        if phase == "outro":
            return dict(speaker="대화가 남긴 질문", text=SALON_DATA["outro"][s["outro_index"]])
        if phase == "topic":
            c = salon_character(s["thinker"])
            return dict(speaker=c["full_name"], text=c["topics"][s["topic_index"]]["lines"][s["line_index"]])
        if phase == "feedback":
            q = salon_question(s)
            c = salon_character(q["thinker"])
            reaction = c["praise"] if s["selected"] == q["answer"] else c["scold"]
            return dict(speaker=c["full_name"], text=reaction+"\n정답: "+q["options"][q["answer"]]+"\n"+q["explanations"][q["answer"]])
        return None

    def salon_sprite(identifier, expression, height=532):
        # Three exact expression columns; crop and scale only at runtime.
        path = "images/%s_pixel.png" % identifier
        width, source_height = renpy.image_size(path)
        column_width = width // 3
        column = {"neutral": 0, "happy": 1, "angry": 2}[expression]
        source = Crop((column*column_width, 0, column_width, source_height), path)
        return Crop((0, 0, 281, 532), Transform(source, xysize=(281, 562), nearest=True))

    def salon_background():
        path = "images/pixel_background.png"
        if not renpy.loadable(path):
            return Solid("#23353a", xysize=(1124, 532))
        width, height = renpy.image_size(path)
        factor = max(1124.0/width, 532.0/height)
        scaled_width, scaled_height = int(round(width*factor)), int(round(height*factor))
        return Crop((max(0, (scaled_width-1124)//2), max(0, (scaled_height-532)//2), 1124, 532), Transform(path, xysize=(scaled_width, scaled_height), nearest=True))

default salon = None

label start:
    $ salon = salon_new_state()
    jump salon_loop

label salon_loop:
    call screen salon_play(salon)
    $ salon = salon_reduce(salon, _return)
    $ renpy.block_rollback()
    jump salon_loop
