# 배움의 방 — Ren'Py 8 프로젝트 설정
init -10 python:
    gui.init(1600, 900)

define config.name = "배움의 방"
define config.version = "1.0"
define config.window_title = "배움의 방"
define config.save_directory = "EducationSalon-2026"
define config.has_sound = False
define config.has_music = False
define config.has_voice = False
define config.rollback_enabled = False
define config.allow_skipping = False
define config.default_text_cps = 0
define config.default_afm_time = 15
define config.window = "hide"
define _game_menu_screen = "salon_pause"
define build.name = "EducationSalon"

init python:
    build.classify("**~", None)
    build.classify("**.bak", None)
    build.classify("**/.**", None)
    build.classify("**/Thumbs.db", None)
    build.documentation("README.md")
    build.documentation("CREDITS.md")
